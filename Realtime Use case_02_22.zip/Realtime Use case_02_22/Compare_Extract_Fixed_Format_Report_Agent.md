# Compare the Extract Fixed Format Report Agent – Technical Design Document

---

## 1. Overview
The Compare Extract Fixed Format Report Agent is designed to validate and compare large-scale extract files from **Mainframe applications (source)** against **Oracle/Unix-converted target extracts**. The files are in fixed format containing **Header, Data, and Trailer records**. The system supports up to **15 million records** with scalable architecture for future growth.

Key goals:
- Accurate record comparison using a **composite key**
- Detailed **column-level mismatch reporting**
- Audit-friendly logging and reporting
- Scalable and hybrid environment deployment

---

## 2. Input Sources

| Source | Format | Metadata Source |
|--------|--------|----------------|
| Mainframe Extract | Fixed-format file | COBOL copybook (primary), fallback JSON/YAML metadata |
| Target Extract (Oracle/Unix) | Fixed-format file | COBOL copybook (primary), fallback JSON/YAML metadata |

Both files contain:
- **Header** (informational)
- **Data records** (to be compared)
- **Trailer** (record count validation)

---

## 3. Key Assumptions

- Composite key is **guaranteed and consistent** in both files.
- Strict exact match on all columns; no normalization or tolerance.
- Files are uploaded manually by the user to initiate comparison.
- Header/Trailer used for informational checks only.
- Short-term retention of results/logs (7–30 days).
- Basic authentication for access control.
- No automated notifications; users manually check UI.

---

## 4. Architecture

### 4.1 Deployment Model
- **Hybrid:** On-premise for file source access, Cloud for scalable processing.
- **Processing Environment:** Cloud-agnostic; can utilize ETL, Python/Java, or distributed engines like Spark if future scalability needed.

### 4.2 System Components

1. **File Upload Module**
   - User uploads Source and Target files.
   - Optional pre-validation for metadata.

2. **Metadata Manager**
   - Parses COBOL copybook or uses fallback JSON/YAML.
   - Provides schema with field name, position, length, datatype.

3. **Processing Engine**
   - Handles **streaming/chunked comparison** to process 15M+ records efficiently.
   - Supports horizontal scaling for future large datasets.

4. **Comparison Logic**
   - Matches records based on **composite key**.
   - Checks **column-level mismatches**.
   - Reports **missing records** in Source/Target.

5. **Logging & Audit Module**
   - Configurable summary and detailed logs.
   - Includes record-level mismatch details and counts.

6. **Result & Reporting Module**
   - UI dashboard for summary.
   - Downloadable CSV/Excel detailed reports.
   - Machine-readable JSON for CI/CD or downstream systems.

7. **Retention Manager**
   - Stores results/logs for **7–30 days**.
   - Configurable cleanup policy.

---

## 5. Processing Flow

1. **File Upload**
   - User uploads Source and Target files.
   - Optional metadata override.

2. **Metadata Parsing**
   - Parse COBOL copybook to generate schema.
   - Fallback to JSON/YAML metadata if COBOL parsing fails.

3. **Pre-validation (Optional)**
   - Check file format, header/trailer count.

4. **Data Comparison**
   - Sort/partition records by composite key.
   - Stream/merge comparison.
   - Identify missing records in Source or Target.
   - Detect column-level mismatches.

5. **Logging**
   - Log record-level mismatches, missing records, and summary.

6. **Reporting**
   - Display summary on UI dashboard.
   - Generate detailed CSV/Excel and JSON reports.

7. **Retention & Cleanup**
   - Retain logs/results for 7–30 days.
   - Automatic cleanup based on retention policy.

---

## 6. Performance & Scalability

- **Chunked/partitioned processing** to handle 15M+ records.
- Horizontally scalable architecture for future datasets (50M+ records).
- Optionally leverage distributed engines (Spark/Hadoop) for very large datasets.

---

## 7. Security

- Basic authentication (username/password) for file upload and result access.
- All sensitive operations logged for audit purposes.

---

## 8. Error Handling

- Enterprise-grade resilient handling:
  - Log errors with detailed messages.
  - Retry minor issues (optional configuration).
  - Fail gracefully for critical issues, notify user via UI.

---

## 9. Summary

The Compare Extract Fixed Format Report Agent is designed to be:
- **Accurate**: column-level mismatch detection, missing record reporting.
- **Scalable**: handles 15M+ records with future-proof architecture.
- **Audit-ready**: detailed logs, summary reports, and retention policy.
- **Hybrid and flexible**: can operate on-prem and in cloud with multiple processing stacks.
- **User-friendly**: manual upload, UI dashboard, downloadable reports.

---

**End of Technical Design Document**
